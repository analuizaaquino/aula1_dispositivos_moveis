let texto = "Olá, mundo!";

console.log(texto.startswith("Olá"));
console.log(texto.endswith("mundo!"));
console.log(texto.includes("mundo"));
console.log("abc".repeat(3));