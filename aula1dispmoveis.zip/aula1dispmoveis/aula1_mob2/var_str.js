let pais = "Brasil";
let continente = "América do Sul";

console.log(pais);
console.log(typeof pais);
console.log(continente);
console.log(typeof continente);

let message1 = "O navio 'Mars' fez escala no porto.";
let message2 = 'Chuva forte passará perto da cidadde de São Paulo';

console.log(message1);
console.log(message2);