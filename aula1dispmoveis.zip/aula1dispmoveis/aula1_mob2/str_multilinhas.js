let multiLineString = ` 
Esta é uma string 
que abrange múltiplas linhas 
sem a necessidade de usar \n.`;

console.log(multiLineString);