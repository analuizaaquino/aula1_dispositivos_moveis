let carro = {
  marca: "Toyota",
  modelo: "Corolla",
  acelerar: function() {
    console.log("O carro está acelerando!");
  }
};

carro.acelerar();