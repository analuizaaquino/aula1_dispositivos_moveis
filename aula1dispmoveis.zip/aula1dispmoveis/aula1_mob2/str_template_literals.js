let nome = "João";
let idade = 30;

//usando template literals
let mensagem = `Olá ${nome}! Você tem ${idade} anos.`;

console.log(mensagem);