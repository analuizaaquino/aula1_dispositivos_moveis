// não alterável
const c = 50;

// 
var a = 1;

// variáveis podem ser locais
let b = 2;
let d = 10;

console.log(a, b, c, d);