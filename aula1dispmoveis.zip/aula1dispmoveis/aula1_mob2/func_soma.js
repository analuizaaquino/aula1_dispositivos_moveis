let resultadoSoma;

function soma(a, b) {
    return a + b;
}

resultadoSoma = soma(1, 2);
console.log("Resultado da Soma: "+resultadoSoma);