let multiplicar = function(a,b){
  return a*b;
}

console.log(multiplicar(4,3));